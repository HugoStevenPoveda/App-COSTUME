package com.costume.costumeRentas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CostumeRentasApplicationTests {

	@Test
	void contextLoads() {
	}

}
