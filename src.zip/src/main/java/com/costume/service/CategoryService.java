/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.costume.service;

import com.costume.model.Category;
import com.costume.repository.CategoryRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author hugog
 */
@Service
public class CategoryService {
    @Autowired
    private CategoryRepository categoryRepository;
    
    
    public List<Category>getAllCategory(){
        List<Category> listCategory =categoryRepository.getAllCategory();
        return listCategory;
    }
    
    public Category saveCategory(Category category){
        Category newCategory;
        if (category.getId() == null){
             newCategory = categoryRepository.saveCategory(category);
             return newCategory;
        }else{
            Optional<Category> categoryExists= categoryRepository.getCategory(category.getId());
            if(categoryExists.isPresent()){
                 return category;
            }else{
              newCategory= categoryRepository.saveCategory(category);
              return newCategory;
            }
        
        
        }
        
    }
    
    
    
    
}
